package com.org.demo.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.org.demo.model.Tutorial;
//import org.springframework.data.jpa.repository.JpaRepository;
//import com.bezkoder.spring.datajpa.model.Tutorial;
public interface Repository extends JpaRepository<Tutorial, Long> {
  static List<Tutorial> findByPublished(boolean published) {
	// TODO Auto-generated method stub
	return null;
}
  List<Tutorial> findByTitleContaining(String title);
}